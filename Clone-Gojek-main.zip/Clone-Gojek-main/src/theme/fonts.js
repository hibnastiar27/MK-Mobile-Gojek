const fontType = {
    'Pjs-ExtraLight' : 'PlusJakartaSans-ExtraLight',
    'Pjs-Light' : 'PlusJakartaSans-Light',
    'Pjs-Regular' : 'PlusJakartaSans-Regular',
    'Pjs-Medium' : 'PlusJakartaSans-Medium',
    'Pjs-SemiBold' : 'PlusJakartaSans-SemiBold',
    'Pjs-Bold' : 'PlusJakartaSans-Bold',
    'Pjs-ExtraBold' : 'PlusJakartaSans-ExtraBold',
}
export default fontType;